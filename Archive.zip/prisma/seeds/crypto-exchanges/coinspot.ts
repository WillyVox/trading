import {
  FeeCalculationBasis,
  FeeCategory,
  OfferingFeatureType,
  OfferingProsConsType,
  OfferingType,
  ProviderSourceType,
  VerificationStatus,
} from "@prisma/client";

export const CoinSpot = {
  provider: {
    name: "CoinSpot",
    slug: "coinspot",
    website: "https://www.coinspot.com.au",
    description:
      "Australian cryptocurrency platform offering Instant Buy/Sell/Swap, Markets and OTC trading, with AUD funding including PayID and Direct Deposit.",
    jurisdictions: ["AU"],
    verificationStatus: VerificationStatus.VERIFIED,
    lastVerifiedAt: new Date("2026-09-17"),
    logo: "/images/providers/coinspot.svg",
    facts: [
      {
        label: "Headquarters / Market",
        value: "Australia",
        jurisdiction: "AU",
        sourceUrl: "https://www.coinspot.com.au",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        label: "Platform Type",
        value:
          "Centralised cryptocurrency platform with instant trading, Markets and OTC",
        jurisdiction: "AU",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        label: "Operating entity",
        value:
          "Casey Block Services Pty Ltd (ACN 619 574 186), trading as CoinSpot",
        jurisdiction: "AU",
        sourceUrl:
          "https://www.coinspot.com.au/public/CoinSpot%20Mastercard%20FSG.pdf?v=410",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
    ],
    sources: [
      {
        label: "Official website",
        url: "https://www.coinspot.com.au",
        sourceType: ProviderSourceType.OFFICIAL_WEBSITE,
      },
      {
        label: "Official fees",
        url: "https://www.coinspot.com.au/fees",
        sourceType: ProviderSourceType.OFFICIAL_FEES,
      },
      {
        label: "Official Financial Services Guide",
        url: "https://www.coinspot.com.au/public/CoinSpot%20Mastercard%20FSG.pdf?v=410",
        sourceType: ProviderSourceType.OFFICIAL_WEBSITE,
      },
    ],
    regulations: [
      {
        jurisdiction: "AU",
        regulator: "AUSTRAC",
        status:
          "Registered Australian digital currency exchange / virtual asset service provider; verify current public-register wording before display",
        sourceUrl: "https://www.coinspot.com.au",
        verifiedAt: new Date("2026-09-17"),
      },
      {
        jurisdiction: "AU",
        regulator: "ASIC",
        status:
          "Casey Block Services Pty Ltd holds AFSL 562554 for financial services described in CoinSpot's FSG; do not imply the AFSL covers all spot-crypto exchange services",
        sourceUrl:
          "https://www.coinspot.com.au/public/CoinSpot%20Mastercard%20FSG.pdf?v=410",
        verifiedAt: new Date("2026-09-17"),
      },
    ],
  },
  offering: {
    name: "CoinSpot Crypto Exchange",
    slug: "coinspot-exchange",
    offeringType: OfferingType.CRYPTO_EXCHANGE,
    jurisdiction: "AU",
    assetSymbols: ["BTC", "ETH", "SOL"],
    fees: [
      {
        feeCategory: FeeCategory.CRYPTO_TRADING,
        label: "Markets order-book fee",
        calculationBasis: FeeCalculationBasis.PERCENTAGE,
        percentage: 0.1,
        displayValue: "0.1%",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        feeCategory: FeeCategory.INSTANT_BUY,
        label: "Instant Buy / Sell / Swap fee",
        calculationBasis: FeeCalculationBasis.PERCENTAGE,
        percentage: 1.0,
        displayValue: "1%",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        feeCategory: FeeCategory.OTHER,
        label: "OTC desk fee",
        calculationBasis: FeeCalculationBasis.PERCENTAGE,
        percentage: 0.1,
        displayValue: "0.1%",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        feeCategory: FeeCategory.FIAT_DEPOSIT,
        label: "AUD PayID / Direct Deposit fee",
        calculationBasis: FeeCalculationBasis.FREE,
        displayValue: "Free",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        feeCategory: FeeCategory.FIAT_DEPOSIT,
        label: "AUD card deposit fee",
        calculationBasis: FeeCalculationBasis.PERCENTAGE,
        percentage: 1.22,
        displayValue: "1.22%",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        feeCategory: FeeCategory.CRYPTO_WITHDRAWAL,
        label: "Crypto withdrawal fee",
        calculationBasis: FeeCalculationBasis.VARIES,
        displayValue:
          "A flat transaction/mining fee applies; current amount is shown on the relevant wallet page",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
    ],
    features: [
      {
        featureType: OfferingFeatureType.AUD_DEPOSITS,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        featureType: OfferingFeatureType.AUD_WITHDRAWALS,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        featureType: OfferingFeatureType.PAYID,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        featureType: OfferingFeatureType.BANK_TRANSFER,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        featureType: OfferingFeatureType.RECURRING_BUYS,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        featureType: OfferingFeatureType.OTC_DESK,
        available: true,
        sourceUrl: "https://www.coinspot.com.au/otc",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
    ],
    prosCons: [
      {
        type: OfferingProsConsType.PRO,
        label: "Markets and OTC trading are priced at 0.1%",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        type: OfferingProsConsType.PRO,
        label:
          "PayID and Direct Deposit are fee-free and AUD bank withdrawals are free",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
      {
        type: OfferingProsConsType.LIMITATION,
        label:
          "Instant Buy/Sell/Swap costs 1%, compared with 0.1% for Markets orders",
        sourceUrl: "https://www.coinspot.com.au/fees",
        verificationStatus: VerificationStatus.VERIFIED,
        verifiedAt: new Date("2026-09-17"),
      },
    ],
  },
};
