import { AffiliatePartnerStatus, CommissionType } from "@prisma/client";

export const Kraken_Links = {
  providerSlug: "kraken",
  partnerSlug: "kraken",
  approvedUrl: "https://www.kraken.com",
  placement: "PROVIDER_PROFILE",
  campaign: "default",
  commissionType: CommissionType.NONE,
  partnershipStatus: AffiliatePartnerStatus.PROSPECT,
  notes:
    "Placeholder affiliate configuration. Replace approvedUrl and activate only after an official affiliate agreement is approved.",
  active: false,
};
