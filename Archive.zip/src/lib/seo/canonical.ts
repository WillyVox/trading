import { absoluteUrl } from "./config";

/**
 * Resolve the canonical URL for a page. Respects an admin-provided override
 * (e.g. Article.canonicalUrl); otherwise derives it from the site-relative
 * path. Never includes query parameters — callers should not pass any.
 */
export function canonicalUrl(path: string, override?: string | null): string {
  if (override && override.trim().length > 0) {
    return override.startsWith("http") ? override : absoluteUrl(override);
  }
  return absoluteUrl(path);
}

/**
 * Comparison pages are reachable in any URL order (e.g. "a-vs-b-vs-c" and
 * "c-vs-a-vs-b" refer to the same comparison). Alphabetical ordering owns
 * the canonical URL for any number of providers so permutations never
 * compete as duplicate content (see Phase 0 audit, §G; generalized in
 * Phase 5 to support 3+-way comparisons).
 */
export function canonicalCompareSlugMulti(slugs: string[]): string {
  return [...slugs].sort((a, b) => a.localeCompare(b)).join("-vs-");
}

/**
 * Splits "a-vs-b-vs-c" into ["a","b","c"]. Supports any number of subjects
 * (Phase 5: "3+-way comparison UI"), not just pairs.
 *
 * Deduplicates: "coinspot-vs-coinspot" is one subject, not two. Previously
 * the domain-specific comparison routes page split without deduping, so a repeated slug
 * rendered the same subject twice -- duplicate React keys in the table
 * header, and a `results.length === slugs.length` existence check that
 * passed on a list it shouldn't have. Deduping here means the canonical
 * redirect collapses it to the single-subject URL instead.
 */
export function parseCompareSlugs(slug: string): string[] {
  return Array.from(new Set(slug.split("-vs-").filter(Boolean)));
}

const REGION_HREFLANG: Record<string, string> = {
  AU: "en-AU",
  UK: "en-GB",
  US: "en-US",
  NZ: "en-NZ",
  SG: "en-SG",
};

/** Region code (e.g. "AU") -> hreflang tag. Falls back to the bare code for regions not yet in the map, rather than guessing. */
export function regionHreflang(region: string): string {
  return REGION_HREFLANG[region.toUpperCase()] ?? region.toLowerCase();
}
