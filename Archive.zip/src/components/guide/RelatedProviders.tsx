import Link from "next/link";
import { Card } from "@/components/ui/Card";
import { VerificationBadge } from "@/components/trust/VerificationBadge";
import { AffiliateDisclosure } from "@/components/affiliate/AffiliateDisclosure";
import { VisitSite } from "../affiliate/VisitSite";

type GuideProvider = {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  verificationStatus: "VERIFIED" | "UNVERIFIED" | "STALE";
  activeLink: boolean;
};

/**
 * "Providers mentioned in this guide" — deliberately not "Best" or
 * "Recommended for you" (see Guide spec §11): those labels require a
 * defensible editorial methodology this component has no way to verify.
 * An affiliate CTA only renders when providers.activeLink is true, which
 * the caller must have derived from a real ACTIVE AffiliateLink lookup —
 * never fabricated here.
 */
export function RelatedProviders({
  providers,
}: {
  providers: GuideProvider[];
}) {
  if (providers.length === 0) return null;

  const anyAffiliate = providers.some((p) => p.activeLink);

  return (
    <section className="border-border mt-10 border-t pt-6">
      <h2 className="font-display text-navy text-lg font-bold">
        Providers mentioned in this guide
      </h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        {providers.map((p) => (
          <Card key={p.id}>
            <div className="flex items-center justify-between">
              <Link
                href={`/crypto/exchanges/${p.slug}`}
                className="font-display text-navy font-semibold hover:underline"
              >
                {p.name}
              </Link>
              <VerificationBadge status={p.verificationStatus} />
            </div>
            {p.description && (
              <p className="text-muted mt-1.5 text-sm">{p.description}</p>
            )}
            <div className="pt-4">
              {p.activeLink ? (
                <VisitSite partnerSlug={p.slug} placement="ArticleDetails" />
              ) : (
                <Link
                  href={`/crypto/exchanges/${p.slug}`}
                  className="border-border text-navy hover:bg-panel-secondary mt-4 inline-flex items-center justify-center rounded-full border px-4 py-2 text-sm font-semibold"
                >
                  View profile
                </Link>
              )}
            </div>
          </Card>
        ))}
      </div>
      {anyAffiliate && <AffiliateDisclosure />}
    </section>
  );
}
