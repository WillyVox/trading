import { Badge } from "@/components/ui/Badge";
import { formatCategoryLabel } from "@/lib/articles/content";

function formatDate(date: Date | string) {
  return new Date(date).toLocaleDateString("en-AU", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function GuideHeader({
  category,
  title,
  excerpt,
  author,
  reviewer,
  publishedAt,
  lastReviewedAt,
  updatedAt,
  readingMinutes,
}: {
  category?: string | null;
  title: string;
  excerpt?: string | null;
  author?: string | null;
  reviewer?: string | null;
  publishedAt?: Date | string | null;
  lastReviewedAt?: Date | string | null;
  updatedAt: Date | string;
  readingMinutes: number;
}) {
  // "Last updated" prefers the editorial lastReviewedAt over the raw
  // updatedAt timestamp (which also changes on non-editorial edits like
  // SEO field tweaks) — see docs/IMPLEMENTATION-PLAN.md Guide Phase 1.
  const lastUpdated = lastReviewedAt ?? updatedAt;

  return (
    <header>
      {category && <Badge tone="gold">{formatCategoryLabel(category)}</Badge>}
      <h1 className="font-display text-navy mt-3 text-3xl font-extrabold sm:text-4xl">
        {title}
      </h1>
      {excerpt && <p className="text-muted mt-3 text-lg">{excerpt}</p>}

      <div className="text-muted mt-4 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
        {author && <span>By {author}</span>}
        {reviewer && <span>Reviewed by {reviewer}</span>}
        {publishedAt && <span>Published {formatDate(publishedAt)}</span>}
        <span>Last updated {formatDate(lastUpdated)}</span>
        {readingMinutes > 0 && <span>{readingMinutes} min read</span>}
      </div>
    </header>
  );
}
