import Link from "next/link";
export function RelatedTools({ offeringSlug }: { offeringSlug?: string }) {
  const links = [
    ...(offeringSlug
      ? [
          {
            href: `/share-trading/${offeringSlug}`,
            label: "View this platform",
          },
        ]
      : []),
    { href: "/compare/trading-platforms", label: "Compare trading platforms" },
    {
      href: "/guides/share-trading-for-beginners",
      label: "Share trading for beginners",
    },
    {
      href: "/tools/trading-cost-calculator",
      label: "Trading cost calculator",
    },
    { href: "/tools/fx-fee-calculator", label: "FX fee calculator" },
    { href: "/tools/crypto-fee-calculator", label: "Crypto fee calculator" },
    { href: "/tools/crypto-cost-calculator", label: "Crypto cost calculator" },
    {
      href: "/tools/regular-investing-calculator",
      label: "Regular investing calculator",
    },
  ];
  return (
    <section aria-labelledby="related-research" className="mt-10">
      <h2
        id="related-research"
        className="font-display text-navy text-2xl font-bold"
      >
        Continue your research
      </h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className="border-border bg-panel text-navy hover:border-gold rounded-xl border p-4 font-semibold transition-colors"
          >
            {link.label} <span aria-hidden="true">→</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
