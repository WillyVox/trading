import {
  getPartnershipsAdmin,
  getProvidersForPartnershipForm,
} from "@/lib/affiliates/service";
import {
  createPartnership,
  updatePartnershipStatus,
} from "@/lib/affiliates/actions";
import { Card } from "@/components/ui/Card";
import { PartnerStatusBadge } from "@/components/admin/PartnerStatusBadge";

const STATUS_OPTIONS = [
  "PROSPECT",
  "APPLIED",
  "APPROVED",
  "ACTIVE",
  "PAUSED",
  "REJECTED",
  "ENDED",
] as const;

export default async function AdminAffiliatePartnersPage() {
  const [partnerships, providers] = await Promise.all([
    getPartnershipsAdmin(),
    getProvidersForPartnershipForm(),
  ]);

  return (
    <div className="space-y-8">
      <Card>
        <h2 className="font-display text-navy text-lg font-bold">
          New partnership
        </h2>
        <p className="text-muted mt-1 text-sm">
          A partnership is the record that a Provider is being pursued as an
          affiliate — it holds no commercial terms itself (that&apos;s the
          Program) and never affects whether the Provider&apos;s profile or
          comparisons render.
        </p>
        <form
          action={createPartnership}
          className="mt-4 flex flex-wrap items-end gap-3"
        >
          <label className="flex flex-col text-sm">
            <span className="text-muted mb-1">Provider</span>
            <select
              name="providerId"
              required
              className="border-border bg-panel-secondary text-navy min-w-[220px] rounded-lg border px-3 py-2"
            >
              {providers.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col text-sm">
            <span className="text-muted mb-1">Initial status</span>
            <select
              name="status"
              defaultValue="PROSPECT"
              className="border-border bg-panel-secondary text-navy rounded-lg border px-3 py-2"
            >
              {STATUS_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </label>
          <button
            type="submit"
            className="bg-navy text-background hover:bg-navy-dark rounded-full px-5 py-2 text-sm font-semibold"
          >
            Create partnership
          </button>
        </form>
        {providers.length === 0 && (
          <p className="text-muted mt-3 text-sm">
            No providers exist yet — seed or add one before creating a
            partnership.
          </p>
        )}
      </Card>

      <Card>
        <h2 className="font-display text-navy text-lg font-bold">
          Partnerships
        </h2>
        {partnerships.length === 0 ? (
          <p className="text-muted mt-4">No partnerships yet.</p>
        ) : (
          <table className="mt-4 w-full text-sm">
            <thead>
              <tr className="border-border text-muted border-b text-left">
                <th className="py-2">Provider</th>
                <th className="py-2">Status</th>
                <th className="py-2">Programs</th>
                <th className="py-2">Links</th>
                <th className="py-2">Update status</th>
              </tr>
            </thead>
            <tbody>
              {partnerships.map((p) => {
                const linkCount = p.programs.reduce(
                  (sum, prog) => sum + prog._count.links,
                  0
                );
                return (
                  <tr key={p.id} className="border-border border-b align-top">
                    <td className="py-3">{p.provider.name}</td>
                    <td className="py-3">
                      <PartnerStatusBadge status={p.status} />
                    </td>
                    <td className="py-3">{p.programs.length}</td>
                    <td className="py-3">{linkCount}</td>
                    <td className="py-3">
                      <form
                        action={updatePartnershipStatus}
                        className="flex items-center gap-2"
                      >
                        <input type="hidden" name="id" value={p.id} />
                        <select
                          name="status"
                          defaultValue={p.status}
                          className="border-border bg-panel-secondary text-navy rounded-lg border px-2 py-1"
                        >
                          {STATUS_OPTIONS.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                        <button
                          type="submit"
                          className="border-border text-navy hover:bg-panel-secondary rounded-full border px-3 py-1 text-xs font-semibold"
                        >
                          Save
                        </button>
                      </form>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
