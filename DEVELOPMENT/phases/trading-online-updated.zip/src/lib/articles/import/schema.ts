import { z } from "zod";
import { IMPORT_REGIONS } from "./types";
import { SLUG_PATTERN } from "@/lib/articles/slug";

/** Mirrors the Prisma `ArticleSearchIntent` enum — see prisma/schema.prisma. Kept as a plain
 * literal list (not imported from @prisma/client) so this module stays usable before `prisma
 * generate` has run, e.g. in Phase 1 dry-runs against a fresh checkout. */
const SEARCH_INTENTS = [
  "LEARN",
  "HOW_TO",
  "BEGINNER",
  "COMPARISON",
  "PROVIDER_GUIDE",
  "FEES",
  "SECURITY",
  "WALLET",
  "REGULATION",
  "MARKET_EDUCATION",
] as const;

export const RELATIONSHIP_TYPES = ["MENTIONED", "COMPARED", "FEATURED"] as const;

/** Mirrors the Prisma `ArticleType` enum — see prisma/schema.prisma. Kept as a plain literal
 * list for the same pre-`prisma generate` reason as SEARCH_INTENTS above. */
const ARTICLE_TYPES = ["NEWS", "GUIDE"] as const;

/**
 * Mirrors the Prisma `ArticleSourceType` enum — see prisma/schema.prisma. `ArticleSource.sourceType`
 * is a real, stored column (added in migration 20260911053226_add_article_layout); this is exported
 * so src/lib/articles/validation.ts (admin CRUD) uses the exact same list rather than a second,
 * hand-maintained copy that could drift.
 */
export const SOURCE_TYPES = [
  "OFFICIAL_PROVIDER",
  "REGULATOR",
  "GOVERNMENT",
  "OFFICIAL_DOCUMENTATION",
  "NEWS",
  "RESEARCH",
  "OTHER",
] as const;

const slugField = z
  .string()
  .trim()
  .min(1, "slug is required")
  .regex(SLUG_PATTERN, 'slug must be lowercase, URL-safe, hyphen-separated (e.g. "how-to-trade-crypto")');

/** Exported for reuse by src/lib/articles/validation.ts (admin CRUD) — one URL-validity rule, not two. */
export const urlField = z.string().trim().refine(
  (value) => {
    try {
      const url = new URL(value);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch {
      return false;
    }
  },
  { message: "must be a valid http(s) URL" }
);

const sourceField = z.object({
  label: z.string().trim().min(1, "source label is required"),
  url: urlField,
  /** Stored on `ArticleSource.sourceType` — see the SOURCE_TYPES comment above. */
  sourceType: z.enum(SOURCE_TYPES).optional(),
  /** @deprecated Renamed to `sourceType` when `ArticleSource.sourceType` shipped. Still accepted
   * (mapped onto `sourceType` in validateFrontmatter below) so existing files keep working. */
  type: z.string().trim().optional(),
});

const providerRelationshipField = z.union([
  z.string().trim().min(1),
  z.object({
    providerSlug: z.string().trim().min(1),
    relationship: z.enum(RELATIONSHIP_TYPES).optional(),
  }),
]);

/** @deprecated Old `{slug, relationship}` shape under the `relatedProviders` key, from before the
 * field was renamed to `providerRelationships` (`providerSlug` instead of `slug`) to match the
 * naming used in the current Article data model / admin editor (src/lib/articles/validation.ts).
 * Still accepted — see validateFrontmatter below — so existing files keep working. */
const legacyProviderRelationshipField = z.union([
  z.string().trim().min(1),
  z.object({
    slug: z.string().trim().min(1),
    relationship: z.enum(RELATIONSHIP_TYPES).optional(),
  }),
]);

/**
 * Raw frontmatter shape, before normalization. Mirrors docs/article-import-format.md.
 * `status` is accepted (so we can warn on it) but is never used to set the stored status —
 * see importer.ts / docs for the DRAFT-only import policy.
 */
export const articleFrontmatterSchema = z.object({
  title: z.string().trim().min(1, "title is required").max(200, "title should be under 200 characters"),
  slug: slugField,
  articleType: z.enum(ARTICLE_TYPES).optional(),
  excerpt: z.string().trim().min(1).optional(),
  category: z.string().trim().min(1).optional(),
  tags: z.array(z.string().trim().min(1)).optional(),
  region: z.enum(IMPORT_REGIONS).optional(),
  canonicalArticleSlug: slugField.optional(),
  seoTitle: z.string().trim().min(1).optional(),
  seoDescription: z.string().trim().min(1).optional(),
  canonicalUrl: urlField.optional(),
  featuredImage: z.string().trim().min(1).optional(),
  featuredImageAlt: z.string().trim().min(1).optional(),
  author: z.string().trim().min(1).optional(),
  reviewer: z.string().trim().min(1).optional(),
  noIndex: z.boolean().optional(),
  affiliateDisclosureRequired: z.boolean().optional(),
  // Advisory only — nothing reads this to auto-publish, same as the admin editor's
  // scheduledAt field. See docs/ROADMAP.md "Scheduling".
  scheduledAt: z.string().trim().optional(),
  // Editorial "meaningfully reviewed" timestamp — distinct from the row's updatedAt.
  lastReviewedAt: z.string().trim().optional(),
  keyTakeaways: z.array(z.string().trim().min(1)).optional(),
  searchIntent: z.enum(SEARCH_INTENTS).optional(),
  providerRelationships: z.array(providerRelationshipField).optional(),
  /** @deprecated use `providerRelationships` — see the comment on legacyProviderRelationshipField. */
  relatedProviders: z.array(legacyProviderRelationshipField).optional(),
  cryptoAssetSlugs: z.array(z.string().trim().min(1)).optional(),
  relatedGuides: z.array(slugField).optional(),
  sources: z.array(sourceField).optional(),
  affiliateProviders: z.array(z.string().trim().min(1)).optional(),
  status: z.string().trim().optional(),
});

export type ArticleFrontmatter = z.infer<typeof articleFrontmatterSchema>;

export interface FrontmatterValidation {
  ok: boolean;
  data?: ArticleFrontmatter;
  errors: string[];
  /** Non-fatal issues — surfaced as WARN, do not block import. */
  warnings: string[];
}

/**
 * Validates raw frontmatter + body against the article contract. Returns both hard errors
 * (block import) and soft warnings (SEO length guidance, ignored `status`, deprecated field
 * names, etc.) — see spec §9 "Do not silently accept malformed values" and §7 (DRAFT-only
 * policy). Normalization of deprecated aliases (`relatedProviders` -> `providerRelationships`,
 * `sources[].type` -> `sources[].sourceType`) happens downstream in parser.ts, which is the
 * single place that turns this validated-but-still-raw shape into the final import payload.
 */
export function validateFrontmatter(raw: unknown, body: string): FrontmatterValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  const result = articleFrontmatterSchema.safeParse(raw);
  if (!result.success) {
    for (const issue of result.error.issues) {
      const path = issue.path.join(".") || "(root)";
      errors.push(`${path}: ${issue.message}`);
    }
    return { ok: false, errors, warnings };
  }

  const data = result.data;

  if (!body || body.trim().length === 0) {
    errors.push("content: body must not be empty");
  }

  if (data.status && data.status.toUpperCase() !== "DRAFT") {
    warnings.push(`status "${data.status}" was ignored — imports are always created as DRAFT`);
  }

  if (!data.articleType) {
    warnings.push(
      'articleType not set — defaulted to "GUIDE". Add "articleType: NEWS" or "articleType: GUIDE" to frontmatter to be explicit.'
    );
  }

  if (data.seoTitle && data.seoTitle.length > 60) {
    warnings.push(`seoTitle is ${data.seoTitle.length} chars — recommended under 60`);
  }
  if (data.seoDescription && data.seoDescription.length > 160) {
    warnings.push(`seoDescription is ${data.seoDescription.length} chars — recommended under 160`);
  }

  if (data.sources) {
    for (const source of data.sources) {
      if (source.type && !source.sourceType) {
        const upper = source.type.toUpperCase();
        if ((SOURCE_TYPES as readonly string[]).includes(upper)) {
          warnings.push(`source "${source.label}" uses deprecated field "type" — rename it to "sourceType"`);
        } else {
          warnings.push(
            `source "${source.label}" has type "${source.type}", which is not a recognized sourceType — ignored`
          );
        }
      } else if (source.type && source.sourceType) {
        warnings.push(`source "${source.label}" has both "type" and "sourceType" set — "sourceType" wins`);
      }
    }
  }

  if (data.relatedProviders) {
    warnings.push(
      '"relatedProviders" is deprecated — rename it to "providerRelationships" (and "slug" to "providerSlug"). Values were still applied.'
    );
  }

  if (data.region && data.region !== "GLOBAL" && !data.canonicalArticleSlug) {
    warnings.push(
      `region "${data.region}" set without canonicalArticleSlug — this will import as a standalone article, not a regional variant`
    );
  }

  if (errors.length > 0) {
    return { ok: false, errors, warnings };
  }

  return { ok: true, data, errors, warnings };
}
