import { getProviderBySlug } from "@/lib/providers/service";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Card } from "@/components/ui/Card";

function parseSlug(slug: string) {
  const parts = slug.split("-vs-");
  return parts.length === 2 ? parts : [slug, null];
}

export default async function CompareDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [a, b] = parseSlug(slug);
  const providerA = await getProviderBySlug(a);
  const providerB = b ? await getProviderBySlug(b) : null;

  return (
    <div className="mx-auto max-w-4xl px-4 py-16">
      <Eyebrow>Compare</Eyebrow>
      <h1 className="mt-4 font-display text-4xl font-extrabold capitalize text-navy">{slug.replace(/-/g, " ")}</h1>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <Card>{providerA ? providerA.name : "Provider not found"}</Card>
        {b && <Card>{providerB ? providerB.name : "Provider not found"}</Card>}
      </div>
    </div>
  );
}
