import { notFound } from "next/navigation";
import { getArticleBySlug } from "@/lib/articles/service";

export default async function GuidePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = await getArticleBySlug(slug);
  if (!article) notFound();
  return (
    <article className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="font-display text-3xl font-extrabold text-navy">{article.title}</h1>
      <div className="prose mt-6" dangerouslySetInnerHTML={{ __html: article.content }} />
    </article>
  );
}
