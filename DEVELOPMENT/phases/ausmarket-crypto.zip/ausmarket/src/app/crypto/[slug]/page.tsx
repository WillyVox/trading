export default async function CryptoAssetPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  return (
    <div className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="font-display text-3xl font-extrabold capitalize text-navy">{slug.replace(/-/g, " ")}</h1>
      <p className="mt-2 text-muted">Asset profile placeholder — content pending Phase 3/4 data.</p>
    </div>
  );
}
