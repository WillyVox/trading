import type { Metadata } from "next";
import { Playfair_Display, Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

// Typography decision: bold high-contrast serif for display headlines
// (Playfair Display), clean sans for UI/body (Inter), and a monospace for
// eyebrow/badge labels (IBM Plex Mono) — matching the DomainEmpire.com
// reference theme. All self-hosted via next/font (no runtime request).
const displayFont = Playfair_Display({
  subsets: ["latin"],
  weight: ["700", "800", "900"],
  variable: "--next-font-display",
  display: "swap",
});

const sansFont = Inter({
  subsets: ["latin"],
  variable: "--next-font-sans",
  display: "swap",
});

const monoFont = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["500", "600"],
  variable: "--next-font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "AusMarket Crypto",
  description: "Independent crypto exchange comparisons and guides for Australia.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${displayFont.variable} ${sansFont.variable} ${monoFont.variable}`}>
      <body>
        <Header />
        <main className="min-h-screen">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
