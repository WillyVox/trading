import type { MetadataRoute } from "next";
import { prisma } from "@/lib/prisma";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXTAUTH_URL ?? "http://localhost:3000";

  const [articles, providers] = await Promise.all([
    prisma.article.findMany({ where: { status: "PUBLISHED", noIndex: false }, select: { slug: true, updatedAt: true } }),
    prisma.provider.findMany({ select: { slug: true, updatedAt: true } }),
  ]);

  const staticRoutes = ["", "/crypto", "/compare", "/methodology", "/news"].map((path) => ({
    url: `${base}${path}`,
  }));

  const articleRoutes = articles.map((a) => ({
    url: `${base}/crypto/guides/${a.slug}`,
    lastModified: a.updatedAt,
  }));

  const providerRoutes = providers.map((p) => ({
    url: `${base}/crypto/exchanges/${p.slug}`,
    lastModified: p.updatedAt,
  }));

  return [...staticRoutes, ...articleRoutes, ...providerRoutes];
}
